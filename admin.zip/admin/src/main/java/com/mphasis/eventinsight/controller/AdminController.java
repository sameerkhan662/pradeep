package com.mphasis.eventinsight.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.eventinsight.dto.User;
import com.mphasis.eventinsight.repo.UserRepository;

@RestController
public class AdminController {

	private @Value("${kafkaTopic}") String kafkaTopic;
	private @Value("$(kafkaURL)") String kafkaURL;
	
	private UserRepository userRepository;
	
	
	private static Logger logger = LogManager.getLogger(AdminController.class.getName());
			
	public AdminController(UserRepository userRepository) {
		this.userRepository=userRepository;
	}

	@CrossOrigin
	@RequestMapping(value = "/login", method = RequestMethod.POST, headers = "Accept=application/json")
	public ServiceResponse userLogin(@RequestBody User loginUser) {

		logger.debug("user login");
        logger.debug("in here......."+loginUser.getEmail());
		User checkLogin= userRepository.findByEmail(loginUser.getEmail());
				
		if(checkLogin!=null) {
			System.out.println("User Exists");
			//Checking password
			if(checkLogin.getPassword().equals(loginUser.getPassword()))
				return ServiceResponse.createSuccessResponse();
			else
				return ServiceResponse.createFailureResponse("Invalid Password Entry. Please try again.");
		}
		else {
			    return ServiceResponse.createFailureResponse("User email does not exists!");
		}
	}
	
	
	@CrossOrigin
	@RequestMapping(value="/startChannel", method= RequestMethod.GET, headers="Accept=application/json")
	public ServiceResponse startChannel(@RequestParam("message") String message) {
		
		ServiceResponse response=null;
		
		try {
		 response=new ServiceResponse();	
		 Map<String, Object> props = new HashMap<>();
		 props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaURL);
		 props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		 props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		
		 ProducerFactory<String, String> producerFactory=new DefaultKafkaProducerFactory<>(props);
		 
		 KafkaTemplate<String, String> kafkaTemplate = new KafkaTemplate<>(producerFactory);
		 
		 logger.debug("Sending meesage to kafka topic :"+kafkaTopic);
		 kafkaTemplate.send(kafkaTopic, message);
		 
		 return ServiceResponse.createSuccessResponse();
		}catch(Exception e) {
		  response.setError("Couldn't send kafka topic");
		  return response;
		}
	
	}
}
