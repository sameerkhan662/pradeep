package com.mphasis.eventinsight.repo;

import org.springframework.data.repository.CrudRepository;

import com.mphasis.eventinsight.dto.User;

public interface UserRepository extends CrudRepository<User, Long>{

	User findByEmail(String email);
}
